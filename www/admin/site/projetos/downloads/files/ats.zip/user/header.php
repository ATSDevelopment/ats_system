<html>
    <head>
        <meta charset="utf-8" />
        <title>ATS Development</title>

        <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css" >
        <link rel="stylesheet" type="text/css" href="css/index.css">
        
        <script src="vendor/jquery/js/jquery-2.1.4.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="vendor/bootstrap/js/npm.js"></script>
    </head>
    <body>

    <?php
    require "navbar.php";
    ?>