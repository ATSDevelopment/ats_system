<?php
define("ROOT", "../");

$cod_projeto = $_GET['cod_projeto'];
require "dao/projeto_dao.class.php";

$pdao = new projeto_dao();
$p = $pdao->obter_por_codigo($cod_projeto);

$nav = "side_btn_p";
require "../header.php";
require "../sidebar.php";
?>

<script src="vendor/tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="js/projetos_tarefas.js"></script>

<div class="sub_body">
	<fieldset>
		<legend><?=$p['nome']?> :: Tarefas</legend>
		<a href="editar.php?cod_projeto=<?=$cod_projeto?>" class="btn btn-primary">
			Voltar
		</a>
		<a href="tarefas_editar.php?cod_projeto=<?=$cod_projeto?>" class="btn btn-primary">
			Adicionar Tarefa
		</a>
</fieldset>
</div>