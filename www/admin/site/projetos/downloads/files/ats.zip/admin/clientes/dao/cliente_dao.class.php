<?php
class cliente_dao {
	function listar_nomes_clientes(){
		require ROOT."config/db_connect.php";

		$prepared = $mysqli->prepare("SELECT codigo, nome_completo FROM clientes");
		$prepared->execute();
		$prepared->bind_result($codigo, $nome_completo);

		$results = array();
		while($prepared->fetch()){
			$results[] = array('codigo' => $codigo, 'nome_completo' => $nome_completo);
		}

		$prepared->close();

		$mysqli->close();

		return $results;
	}
}
?>