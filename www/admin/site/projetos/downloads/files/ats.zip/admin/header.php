<!DOCTYPE html>
<html>
<head>
	<title>ATS Development</title>
	<link rel="stylesheet" type="text/css" href="<?=ROOT.'/vendor/bootstrap/css/bootstrap.min.css'?>">
	
	<script type="text/javascript" src="<?=ROOT.'/vendor/jquery/js/jquery-2.1.4.min.js'?>"></script>
	<script type="text/javascript" src="<?=ROOT.'/vendor/bootstrap/js/bootstrap.min.js'?>"></script>
</head>
<body>