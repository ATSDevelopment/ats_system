$(document).ready(function(){
	tinymce.init({
		selector: "textarea"
	});
});