<?php
define("ROOT", "../../");

require "tarefa_dao.class.php";

$f = array();

$f['sv_tarefa'] = function(){
	$_POST['codigo'] = $_GET['cod_tarefa'];
	$_POST['cod_projeto'] = $_GET['cod_projeto'];

	$dao = new tarefa_dao();
	$dao->salvar_tarefa($_POST);

	Header("Location: ../tarefas_editar.php?cod_projeto=".$_GET['cod_projeto']."&cod_tarefa=".$_POST['cod_tarefa']);
};

if(array_key_exists("op", $_GET)){
	$f[$_GET['op']]();

	echo "ok";
}
?>