<?php
class tarefa_dao{
	function salvar_tarefa(&$t){
		require ROOT."config/db_connect.php";

		$query = "INSERT INTO tarefas SET nome='".$t['titulo']."', descricao='".$t['descricao']."', concluida=false, cod_funcionario='".$t['cod_funcionario']."', cod_projeto='".$t['cod_projeto']."'";


		if($t['codigo'] == 0){
			$query = "INSERT INTO tarefas SET nome=?, descricao=?, concluida=false, cod_funcionario=?, cod_projeto=?";
		}else{
			$query = "UPDATE tarefas SET nome=?, descricao=?, concluida=false, cod_funcionario=?, cod_projeto WHERE codigo=?";
		}

		$prepared = $mysqli->prepare($query);
		if($t['codigo'] == 0){
			$prepared->bind_param("ssii", $t['titulo'], $t['descricao'], $t['cod_funcionario'], $t['cod_projeto']);
		}else{
			$prepared->bind_param("ssiii", $t['titulo'], $t['descricao'], $t['cod_funcionario'], $t['cod_projeto'], $t['codigo']);
		}

		$prepared->execute();

		if($t['codigo'] == 0){
			$t['codigo'] = $prepared->insert_id;
		}

		$prepared->close();
	}
}
?>