<?php
define("ROOT", "./");

require "header.php";
require "sidebar.php";
?>
<script type="text/javascript">
	console.log();
</script>
<?php
require "footer.php"
?>