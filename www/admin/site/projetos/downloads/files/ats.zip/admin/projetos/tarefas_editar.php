<?php
define("ROOT", "../");

$cod_projeto = $_GET['cod_projeto'];
$cod_tarefa=0;
if(array_key_exists("cod_tarefa", $_GET)){
	$cod_tarefa = $_GET['cod_tarefa'];
}
require "dao/projeto_dao.class.php";

$dao = new projeto_dao();
$participantes = $dao->listar_participantes($cod_projeto);

$nav = "side_btn_p";
require "../header.php";
require "../sidebar.php";
?>
<link rel="stylesheet" type="text/css" href="css/tarefas_editar.css">

<script src="../vendor/tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="../js/tinymce_init.js"></script>

<div class="sub_body">
	<fieldset>
		<legend>Editar Tarefa</legend>
		<form class="panel panel-default panel-body" method="post" action="dao/tarefa_dao.php?op=sv_tarefa&cod_projeto=<?=$cod_projeto?>&cod_tarefa=<?=$cod_tarefa?>">
			<div class="row">
				<div class="col-lg-2">
					<label>Título</label>
				</div>
				<div class="col-lg-10">
					<input name="titulo" type="text" class="form-control">
				</div>
			</div>

			<br />

			<div class="row">
				<div class="col-lg-2">
					<label>Funcionário</label>
				</div>
				<div class="col-lg-10">
					<select name="cod_funcionario" class="form-control">
						<?php
						foreach ($participantes as $p) {
							?>
							<option value="<?=$p['codigo']?>"><?=$p['nome_completo']?></option>
							<?php
						}
						?>
					</select>
				</div>
			</div>

			<br />

			<label>Descrição</label>
			<br />
			<textarea name="descricao"></textarea>
			<br />
			<div class="btn-group" role="group">
				<a type="button" class="btn btn-default">Voltar</a>
				<a type="button" class="btn btn-default">Deletar</a>
				<button type="submit" class="btn btn-primary">Salvar</button>
			</div>
		</form>
	</fieldset>
</div>
<?php
require "../footer.php";
?>