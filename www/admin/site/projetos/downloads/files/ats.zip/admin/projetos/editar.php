<?php
define("ROOT", "../");

$p = null;

if(array_key_exists("cod_projeto", $_GET)){
	require "dao/projeto_dao.class.php";

	$dao = new projeto_dao();
	$p = $dao->obter_por_codigo($_GET['cod_projeto']);
}

require ROOT."clientes/dao/cliente_dao.class.php";

$cdao = new cliente_dao();
$clientes = $cdao->listar_nomes_clientes();

$nav = "side_btn_p";
require "../header.php";
require "../sidebar.php";
?>

<script src="../vendor/tinymce/js/tinymce/tinymce.min.js"></script>
<script src="../js/tinymce_init.js"></script>

<link rel="stylesheet" type="text/css" href="css/projetos_editar.css">

<div class="sub_body">
	<fieldset>
		<legend>Cadastro de Projetos</legend>
		<div id="p_editor" class="panel panel-default">
			<div class="panel-body">
				<form name="form_projeto" method="post" action="dao/projeto_dao.php?op=salvar_projeto&cod_projeto=<?=$p['codigo']?>">
					<div class="row input_row">
						<div class="col-lg-2">
							<label>Nome do Projeto:</label>
						</div>
						<div class="col-lg-10">
							<input name="nome" type="text" class="form-control" />
						</div>
					</div>

					<div class="input_row">
						<label>Descrição: </label>
						<textarea name="descricao" rows="10"></textarea>
					</div>

					<div class="row input_row">
						<div class="col-lg-1">
							<label>Cliente:</label>
						</div>
						<div class="col-lg-11">
							<select name="cod_cliente" type="text" class="form-control" >
								<?php
								foreach ($clientes as $c) {
									?>

									<option id="op_client_<?=%c['codigo']?>" value="<?=$c['codigo']?>"><?=$c['nome_completo']?></option>

									<?php
								}
								?>
							</select>
						</div>
					</div>

					<div id="controls">
						<a href="listar.php" class="btn btn-primary">Voltar</a>

						<div id="con_ger" class="btn-group" role="group" aria-label="...">
							<a id="btn_ger_tarefas" href="tarefas.php?cod_projeto=<?=$p['codigo']?>" class="btn btn-primary disabled">Gerenciar Tarefas</a>
							<a href="participantes.php?cod_projeto=<?=$p['codigo']?>" class="btn_unlock btn btn-primary disabled">Gerenciar Participantes</a>
						</div>
						<div id="con_sd" class="btn-group" role="group" aria-label="...">
							<a href="dao/projeto_dao.php?op=deletar_projeto&cod_projeto=<?=$p['codigo']?>" class="btn_unlock btn btn-primary disabled">Deletar</a>
							<a id="btn_fr_projeto" href="#" class="btn_unlock btn btn-primary disabled">...</a>
							<button type="submit" class="btn btn-primary">Salvar</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</fieldset>
</div>

<?php
if($p != null){
	?>
	<script type="text/javascript">

		document.form_projeto.nome.value="<?=$p['nome']?>";
		document.form_projeto.descricao.value="<?=$p['descricao']?>";

		$(".btn_unlock").toggleClass("disabled");

		console.log("concluído: <?=$p['concluido']?>");
		<?php
		if(!$p['concluido']){
			?>
			$("#btn_fr_projeto").attr("href", "dao/projeto_dao.php?op=finalizar_projeto&cod_projeto=<?=$p['codigo']?>");
			$("#btn_fr_projeto").html("Finalizar");
			<?php
		}else{
			?>
			$("#btn_fr_projeto").attr("href", "dao/projeto_dao.php?op=reabrir_projeto&cod_projeto=<?=$p['codigo']?>");
			$("#btn_fr_projeto").html("Reabrir");
			<?php
		}

		if($p['n_participantes'] > 0){
			?>
			$("#btn_ger_tarefas").toggleClass("disabled");
			<?php
		}
		?>
	</script>
	<?php
}
require "../footer.php";
?>