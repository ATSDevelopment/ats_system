function preencher(t){
	console.log(t);
	document.form.nome.value = t.nome;
	document.form.cod_funcionario.value = t.funcionario.codigo;
	document.form.descricao.value = t.descricao;
}