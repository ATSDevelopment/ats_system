<?php
header("Location: site/login/login.php");
?>