<?php
define("ROOT", "./");

require "header.php";
require "sidebar.php";
require "footer.php"
?>