<?php
require ROOT."/libs/db_connect.php";
require ROOT."/libs/UsuarioDAO/UsuarioDAO.class.php";
require ROOT."/libs/FuncionarioDAO/FuncionarioDAO.class.php";
require ROOT."/libs/ClienteDAO/ClienteDAO.class.php";
require ROOT."/libs/ProjetoDAO/ProjetoDAO.class.php";
require ROOT."/libs/DownloadDAO/DownloadDAO.class.php";
?>