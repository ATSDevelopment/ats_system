package app;

import dao.ClienteDAO;
import entity.Cliente;

public class Launcher {

	public static void main(String[] args) {
		Cliente c = new Cliente();
		c.setCodigo(3);
		c.setNome("Calos Souza Rodrigues Filho");
		c.setEndereco("Endereço");
		c.setBairro("São João de Petrópolis");
		c.setCidade("Santa Teresa - ES");
		c.setEstado("ES");
		c.setEmail("car.s.r.f@gmail.com");
		c.setTelefone("999010796");
		
		ClienteDAO dao = new ClienteDAO();
		dao.deletar(c);
		System.out.println(dao.listar());
	}

}
