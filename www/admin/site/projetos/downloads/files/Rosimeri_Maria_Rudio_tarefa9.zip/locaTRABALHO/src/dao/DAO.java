package dao;

import java.util.List;

public interface DAO <Entity>{
	public void salvar(Entity entity);
	public void deletar(Entity entity);
	public List<Entity> listar();
}
