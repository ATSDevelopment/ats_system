package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import config.ConnectionFactory;
import entity.Cliente;

public class ClienteDAO implements DAO<Cliente>{

	@Override
	public void salvar(Cliente c) {
		Connection conexao = null;
		try {
			conexao = ConnectionFactory.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		
		String query;
		if(c.getCodigo() == 0){
			query = "INSERT INTO cliente SET nome_cliente=?, endereco_cliente=?, bairro_cliente=?, cidade_cliente=?, estado_cliente=?, telefone_cliente=?, email=?";
		}else{
			query = "UPDATE cliente SET nome_cliente=?, endereco_cliente=?, bairro_cliente=?, cidade_cliente=?, estado_cliente=?, telefone_cliente=?, email=? WHERE cod_cliente=?";
		}
		
		try {
			PreparedStatement ps = conexao.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, c.getNome());
			ps.setString(2, c.getEndereco());
			ps.setString(3, c.getBairro());
			ps.setString(4, c.getCidade());
			ps.setString(5, c.getEstado());
			ps.setString(6, c.getTelefone());
			ps.setString(7, c.getEmail());
			
			if(c.getCodigo() != 0){
				ps.setInt(8, c.getCodigo());
			}
			ps.execute();
			
			if(c.getCodigo() == 0){
				ResultSet rs = ps.getGeneratedKeys();
				if(rs.next()){
					c.setCodigo(rs.getInt(1));
				}
				rs.close();
			}
			ps.close();
			
			conexao.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void deletar(Cliente c) {
		Connection conexao = null;
		try {
			conexao = ConnectionFactory.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		
		try {
			PreparedStatement ps = conexao.prepareStatement("DELETE FROM cliente WHERE cod_cliente=?");
			ps.setInt(1, c.getCodigo());
			ps.execute();
			ps.close();
			
			conexao.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Cliente> listar() {
		Connection conexao = null;
		try {
			conexao = ConnectionFactory.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		
		List<Cliente> ls = new ArrayList<Cliente>();
		try {
			PreparedStatement ps = conexao.prepareStatement("SELECT * FROM cliente");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Cliente c = new Cliente();
				c.setCodigo(rs.getInt("cod_cliente"));
				c.setNome(rs.getString("nome_cliente"));
				c.setEndereco(rs.getString("endereco_cliente"));
				c.setBairro(rs.getString("bairro_cliente"));
				c.setCidade(rs.getString("cidade_cliente"));
				c.setEstado(rs.getString("cidade_cliente"));
				c.setTelefone(rs.getString("telefone_cliente"));
				c.setEmail(rs.getString("email"));
				
				ls.add(c);
			}
			rs.close();
			ps.close();
			
			conexao.close();
			
			return ls;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return null;
	}
}
